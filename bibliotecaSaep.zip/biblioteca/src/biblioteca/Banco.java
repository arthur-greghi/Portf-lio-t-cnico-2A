package biblioteca;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.naming.spi.DirStateFactory;

public class Banco {

    private static Connection connection;

    public static Connection getConnection() {
        if (connection == null) {
            try {

                Class.forName("org.postgresql.Driver");
                String host = "localhost";
                String port = "5432";
                String database = "biblioteca";
                String user = "postgres";
                String pass = "postgres";

                String url = "jdbc:postgresql://" + host + ":" + port + "/" + database;
                connection = DriverManager.getConnection(url, user, pass);

            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return connection;
    }

    public static void close() {
        if (connection == null) {
            throw new RuntimeException("Nenhuma conexão aberta!");
        } else {
            try {
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public static boolean logarBibliotecaria(String cpf, String tabela) {
        try {
            Connection con = Banco.getConnection();
            PreparedStatement ps = con.prepareStatement("SELECT * from " + tabela);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                if (cpf.equals(rs.getString(1))) {
                    return true;
                }

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public static void cadastrarAluno(Aluno aluno) {
        try {
            Connection con = Banco.getConnection();
            PreparedStatement ps = con.prepareStatement("INSERT INTO aluno (matricula, nome, email, telefone, data_nascimento) values(?, ?, ?, ?, ?)");
            ps.setString(1, aluno.getMatricula());
            ps.setString(2, aluno.getNome());
            ps.setString(3, aluno.getEmail());
            ps.setString(4, aluno.getTelefone());
            ps.setString(5, aluno.getData_nascimento());

            ps.execute();
        } catch (SQLException e) {
            e.printStackTrace();

        }
    }
 public static void cadastrarLivro(Livro livro) {
        try {
            Connection con = Banco.getConnection();
            PreparedStatement ps = con.prepareStatement("INSERT INTO livros (cod, titulo, autor, editora, ano) values(?, ?, ?, ?, ?)");
            ps.setString(1, livro.getCod());
            ps.setString(2, livro.getTitulo());
            ps.setString(3, livro.getAutor());
            ps.setString(4, livro.getEditora());
            ps.setInt(5, livro.getAno());

            ps.execute();
        } catch (SQLException e) {
            e.printStackTrace();

        }
    }
    public static String visualizaEmprestimo(String tabela, String... atributos) {
        try {
            Connection con = Banco.getConnection();
            PreparedStatement ps = con.prepareStatement("SELECT * FROM emprestimo");
            ResultSet rs = ps.executeQuery();
            String selectfrom = " ";
            while (rs.next()) {

                for (String i : atributos) {
                    selectfrom = selectfrom + "  |  " + rs.getString(i);

                }
                selectfrom = selectfrom + "\n";
            }
            return selectfrom;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return " ";
    }
}

  