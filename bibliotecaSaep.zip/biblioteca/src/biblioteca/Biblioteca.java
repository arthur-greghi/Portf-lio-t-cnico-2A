package biblioteca;

 class Biblioteca {
  public static void main(String[] args) {
        TelaInicio tela = new TelaInicio();
        tela.setVisible(true);
    }
    
}
