package com.example.jogodavelha;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    String ultimo = "O";
    String[][] velha = {{"a", "b", "c"}, {"d", "e", "f"}, {"g", "h", "i"}};
    Button b00, b01, b02, b10, b11, b12, b20, b21, b22;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        b00 = findViewById(R.id.b00);
        b01 = findViewById(R.id.b01);
        b02 = findViewById(R.id.b02);
        b10 = findViewById(R.id.b10);
        b11 = findViewById(R.id.b11);
        b12 = findViewById(R.id.b12);
        b20 = findViewById(R.id.b20);
        b21 = findViewById(R.id.b21);
        b22 = findViewById(R.id.b22);
    }

    public void define() {
        if (ultimo.equals("O")) {
            ultimo = "X";
        } else {
            ultimo = "O";
        }
    }

    public void cb00(View v) {
        define();
        b00.setText(ultimo);
        velha[0][0] = ultimo;
        b00.setEnabled(false);
    }

    public void cb01(View v) {
        define();
        b01.setText(ultimo);
        velha[0][0] = ultimo;
        b01.setEnabled(false);
    }

    public void cb02(View v) {
        define();
        b02.setText(ultimo);
        velha[0][0] = ultimo;
        b02.setEnabled(false);
    }

    public void cb10(View v) {
        define();
        b10.setText(ultimo);
        velha[0][0] = ultimo;
        b10.setEnabled(false);
    }

    public void cb11(View v) {
        define();
        b11.setText(ultimo);
        velha[0][0] = ultimo;
        b11.setEnabled(false);
    }

    public void cb12(View v) {
        define();
        b12.setText(ultimo);
        velha[0][0] = ultimo;
        b12.setEnabled(false);
    }

    public void cb20(View v) {
        define();
        b20.setText(ultimo);
        velha[0][0] = ultimo;
        b20.setEnabled(false);
    }

    public void cb21(View v) {
        define();
        b21.setText(ultimo);
        velha[0][0] = ultimo;
        b21.setEnabled(false);
    }

    public void cb22(View v) {
        define();
        b22.setText(ultimo);
        velha[0][0] = ultimo;
        b22.setEnabled(false);
    }

    public void reiniciar(View v){
        b00.setText("");
        b01.setText("");
        b02.setText("");
        b10.setText("");
        b11.setText("");
        b12.setText("");
        b20.setText("");
        b21.setText("");
        b22.setText("");
        b00.setEnabled(true);
        b01.setEnabled(true);
        b02.setEnabled(true);
        b10.setEnabled(true);
        b11.setEnabled(true);
        b12.setEnabled(true);
        b20.setEnabled(true);
        b21.setEnabled(true);
        b22.setEnabled(true);
    }
}